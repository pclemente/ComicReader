ComicReader App Review Sample
=============================

This attachment contains one public-domain CBZ comic for testing ComicReader's Files import and reader.

Import steps
------------
1. Unzip the outer review-sample.zip attachment.
2. Keep little-nemo-01-bed-adrift.cbz compressed; a CBZ is the comic file.
3. Save the CBZ somewhere visible in the iPad Files app, such as Downloads or On My iPad.
4. Launch ComicReader, tap Settings in the upper-right corner, then tap Add Files.
5. Select little-nemo-01-bed-adrift.cbz in the Files picker.
6. Tap its cover in the library. Swipe or tap the left and right edges to change pages; double-tap a page to test zoom.

No account, sign-in, purchase, or network connection is required for this test.

The CBZ contains a designed cover and three normalized 1905 Little Nemo in Slumberland scans. See CREDITS.txt for the public-domain sources. The excluded 1907 source scan named page-03.jpg is not present.
